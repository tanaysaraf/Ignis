from django.contrib import admin
from .models import LikeButton
# Register your models here.
admin.site.register(LikeButton)