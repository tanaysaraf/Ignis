# Like_button_using_django_and_AJAX
<h2>Article link</h2>
https://medium.com/@nishalk25121999/how-to-make-a-like-button-using-django-ajax-d2db38e6d2f8 


<h3>Reference:</h3>
https://stackoverflow.com/questions/14007453/my-own-like-button-django-ajax-how
