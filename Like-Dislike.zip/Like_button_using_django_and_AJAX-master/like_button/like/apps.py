from django.apps import AppConfig


class LikeConfig(AppConfig):
    name = 'like'
